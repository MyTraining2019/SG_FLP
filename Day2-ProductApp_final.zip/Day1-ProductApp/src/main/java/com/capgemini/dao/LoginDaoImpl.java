package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.model.Login;
import com.capgemini.model.Product;

public class LoginDaoImpl implements LoginDao{
	
	
	public Connection getDBConnection() {
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/SG_Training",
					"root","admin");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	@Override
	public boolean isValidLogin(Login login) {
		
		boolean flag=false;
		String sql="select * from login where username=? and userpassword=?";
		
		try {
			PreparedStatement pst= getDBConnection().prepareStatement(sql);
			pst.setString(1, login.getUserName());
			pst.setString(2, login.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			if(rs.next())
				flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return flag;
	}

	@Override
	public void createProduct(Product product) {
		String sql="insert into product(productName,productType,expiryDate,description,quantity,price) "
				+ "values (?,?,?,?,?,?)";
		try {
			PreparedStatement pst=getDBConnection().prepareStatement(sql);
			pst.setString(1, product.getProductName());
			pst.setString(2, product.getProductType());
			
			long myDateValue=product.getExpiryDate().getTime();
			pst.setDate(3, new Date(myDateValue) );
			pst.setString(4, product.getDescription());
			pst.setInt(5, product.getQuantity());
			pst.setDouble(6, product.getPrice());
			
			int count=pst.executeUpdate();
			
			if(count>0)
				System.out.println("record inserted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> products=new ArrayList<>();
		
		String sql="select * from product";
		
		try {
			PreparedStatement pst= getDBConnection().prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				Product product=new Product();
				product.setProductId(rs.getInt("productId"));
				product.setProductName(rs.getString("productName"));
				product.setDescription(rs.getString("description"));
				product.setProductType(rs.getString("productType"));
				product.setQuantity(rs.getInt("quantity"));
				product.setPrice(rs.getDouble("price"));
				product.setExpiryDate(new java.util.Date(rs.getDate("expiryDate").getTime()));
				
				
				products.add(product);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return products;
	}

	@Override
	public void deleteProduct(int productId) {
		String sql="delete from product where productId=?";
		try {
			PreparedStatement pst=getDBConnection().prepareStatement(sql);
			pst.setInt(1, productId);
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
