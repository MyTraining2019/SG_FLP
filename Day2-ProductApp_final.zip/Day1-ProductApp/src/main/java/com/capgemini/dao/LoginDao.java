package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Login;
import com.capgemini.model.Product;

public interface LoginDao {
	
	public boolean isValidLogin(Login login);
	public void createProduct(Product product);
	public List<Product> getAllProducts();
	public void deleteProduct(int productId);

}
