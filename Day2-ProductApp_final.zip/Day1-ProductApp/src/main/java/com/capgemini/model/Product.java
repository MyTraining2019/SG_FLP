package com.capgemini.model;

import java.util.Date;

public class Product {
	private int productId;
	private String productName;
	private String productType;
	private String description;
	private Date expiryDate;
	private int quantity;
	private double price;
	private String email;
	
	public Product() {
		
	}
	
	
	public Product(String productName, String productType, String description, Date expiryDate, int quantity,
			double price, String email) {
		super();
		this.productName = productName;
		this.productType = productType;
		this.description = description;
		this.expiryDate = expiryDate;
		this.quantity = quantity;
		this.price = price;
		this.email = email;
	}


	public Product(int productId, String productName, String productType, String description, Date expiryDate,
			int quantity, double price, String email) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productType = productType;
		this.description = description;
		this.expiryDate = expiryDate;
		this.quantity = quantity;
		this.price = price;
		this.email = email;
	}


	public Product(String productName, String productType, String description, Date expiryDate, int quantity,
			double price) {
		super();
		this.productName = productName;
		this.productType = productType;
		this.description = description;
		this.expiryDate = expiryDate;
		this.quantity = quantity;
		this.price = price;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	@Override
	public String toString() {
		return "Product [productName=" + productName + ", productType=" + productType + ", description=" + description
				+ ", expiryDate=" + expiryDate + ", quantity=" + quantity + ", price=" + price + ", email=" + email
				+ "]";
	}


	
	
	

}
