package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class createServlet
 */
public class createServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out= response.getWriter();
		//Access Session Object
				HttpSession mysession=request.getSession();
				String userName=mysession.getAttribute("myuser").toString();
				
		
		out.println(""
				+ "<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset='ISO-8859-1'>\r\n" + 
				"<title>Product Page</title>\r\n" + 
				"<link href='../styles/mystyles.css' type='text/css' rel='stylesheet'>\r\n" + 
				"<style type='text/css'>\r\n" + 
				".mylink{\r\n" + 
				"	width:100px;\r\n" + 
				"	float: left;\r\n" + 
				"	padding: 5px 5px 5px 5px;\r\n" + 
				"}\r\n" + 
				"a:link{\r\n" + 
				"	\r\n" + 
				"	text-decoration: none;\r\n" + 
				"	background-color: blue;\r\n" + 
				"	color: white;\r\n" + 
				"	font-size: 20px;\r\n" + 
				"	font-weight: bold;\r\n" + 
				"	\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"</style>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<h2 align='center'>Product Application</h2>\r\n" + 
				"\r\n" + 
				"<hr>\r\n" + 
				"\r\n" + 
				"<div style='display: inline-block;'>\r\n" + 
				"<div class='mylink'>	<a href='pages/createProduct.html' target='mainFrm'>Create</a> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>\r\n" + 
				"<div class='mylink'>	<a href='#' target='mainFrm'>Update</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>\r\n" + 
				"<div class='mylink'>	<a href='#' target='mainFrm'>Delete</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>\r\n" + 
				"<div class='mylink'>	<a href='listAllServlet' target='mainFrm'>ListAll</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>\r\n" + 
				"<div class='mylink'>	<a href='logoutServlet' target='_parent'>Logout</a>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>\r\n" + 
				"	\r\n"
				+ "<div style='margin-left:600px;color:red;'>Hello!!!" + userName+"</div>"+
				"</div>\r\n" + 
				"<div id='mainCnt'>\r\n" + 
				"\r\n" + 
				"<iframe name='mainFrm' src='pages/welcomePage.html' style='width: 1000px; height: 500px; border: 1px solid black;'>\r\n" + 
				"\r\n" + 
				"</iframe>\r\n" + 
				"</div>\r\n" + 
				"\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
