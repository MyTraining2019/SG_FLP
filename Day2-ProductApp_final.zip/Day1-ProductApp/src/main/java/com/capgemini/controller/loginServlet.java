package com.capgemini.controller;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.model.Login;
import com.capgemini.service.LoginService;
import com.capgemini.service.LoginServiceImpl;


public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ServletContext servletContext;
	private String compEmail;
	
	
	@Override
	public void destroy() {
		System.out.println("Servlet Destroyed...");
	}





	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Servlet Initialized....");
		servletContext=config.getServletContext();
		compEmail=config.getInitParameter("email");
	}





	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		
		System.out.println("Email:" + compEmail);
		
		//context Param
		
		String cmpName=servletContext.getInitParameter("companyName");
		
		System.out.println("LoginServlet---->CompanyName:" + cmpName);
		
		System.out.println("Servlet Service....");
		
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		
		//Bind input with POJO
		Login login=new Login();
		login.setUserName(userName);
		login.setUserPwd(userPwd);
		
		
		LoginService loginService=new LoginServiceImpl();
		boolean value= loginService.isValidUser(login);
		
		if(value) {
			
			//Session
			HttpSession mysession= request.getSession();
			mysession.setAttribute("myuser", login.getUserName());
			
			
			Cookie myCookie=new Cookie("userName", login.getUserName());
			Cookie myCookie1=new Cookie("userPassword", login.getUserPwd());
			
			response.addCookie(myCookie);
			response.addCookie(myCookie1);
			
			Cookie[] cookies=request.getCookies();
			if(cookies!=null) {
			for(Cookie cookie:cookies)
				System.out.println(cookie.getName() +"--" + cookie.getValue());
			}
			response.sendRedirect("createServlet");
			/*request.getRequestDispatcher("pages/product.html")
						.forward(request, response);*/
		}
		else
			//response.sendRedirect("home.html");
			request.getRequestDispatcher("home.html")
			.forward(request, response);
		
	}

}
