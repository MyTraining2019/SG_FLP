package com.capgemini.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.model.Product;
import com.capgemini.service.LoginService;
import com.capgemini.service.LoginServiceImpl;


public class saveProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private LoginService loginService=new LoginServiceImpl();
	private ServletContext servletContext;
	private String compEmail;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Servlet Initialized....");
		servletContext=config.getServletContext();
		
		compEmail=config.getInitParameter("email");
	}

	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
	
		//context Param
		
				String cmpName=servletContext.getInitParameter("companyName");
				
				System.out.println("SaveServlet---->CompanyName:" + cmpName);
				
				System.out.println("Servlet Service....");
		
		String productName=request.getParameter("productName");
		String productType=request.getParameter("productType");
		String expiryDate=request.getParameter("expiryDate");
		String description=request.getParameter("description");
		String quantity=request.getParameter("quantity");
		String price=request.getParameter("price");
		
		
		Product product=new Product();
		product.setProductName(productName);
		product.setProductType(productType);
		product.setDescription(description);
		product.setQuantity(Integer.parseInt(quantity));
		product.setPrice(Double.parseDouble(price));
		System.out.println(expiryDate);
		String[] exDate=expiryDate.split("-");
		
		product.setExpiryDate(new Date(Integer.parseInt(exDate[0])-1900,
								Integer.parseInt(exDate[1]),
						Integer.parseInt(exDate[2])));
		
		product.setEmail(compEmail);
		System.out.println("Email:" + compEmail);
		
		//System.out.println(product);
		
		loginService.createProduct(product);
		
		response.sendRedirect("pages/createProduct.html");		
		
		
	}

}
