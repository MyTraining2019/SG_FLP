package com.capgemini.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.service.LoginService;
import com.capgemini.service.LoginServiceImpl;


public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService loginService;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productId=Integer.parseInt(request.getParameter("productId"));
		
		
		Cookie[] cookies=request.getCookies();
		if(cookies!=null) {
		for(Cookie cookie:cookies)
			System.out.println(cookie.getName() +"--" + cookie.getValue());
		}
		
		loginService=new LoginServiceImpl();
		
		loginService.deleteProduct(productId);
		
		request.getRequestDispatcher("listAllServlet").forward(request, response);
	
	}

}
