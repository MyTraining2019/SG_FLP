package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.model.Product;
import com.capgemini.service.LoginService;
import com.capgemini.service.LoginServiceImpl;

public class listAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private LoginService loginService;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		loginService=new LoginServiceImpl();
		
		
		//Access Session Object
		HttpSession mysession=request.getSession();
		String userName=mysession.getAttribute("myuser").toString();
		
		
		
		Cookie[] cookies=request.getCookies();
		if(cookies!=null) {
		for(Cookie cookie:cookies)
			System.out.println(cookie.getName() +"--" + cookie.getValue());
		}
		
		List<Product> products= loginService.getAllProducts();
	
		
		PrintWriter out=response.getWriter();
		
		out.println("<html><body>"
				+ "<h3 align='center'>Product List</h3>"
				+ "<div style='margin-left:500px;color:red'>Hello!" + userName +"</div>"
				+ "<hr>"
				+ "<form action='deleteServlet'>"
				+ "<table>"
				+ "<tr>"
				+ "<th>ProductId</th>"
				+ "<th>ProductName</th>"
				+ "<th>ProductType</th>"
				+ "<th>ExpiryDate</th>"
				+ "<th>Description</th>"
				+ "<th>Quantity</th>"
				+ "<th>Price</th>"
				+ "<th>Edit</th>"
				+ "</tr>");
		
		for(Product product:products) {
			out.println("<tr>"
					+ "<td>"+product.getProductId()+"</td>"
					+ "<td>"+product.getProductName()+"</td>"
					+ "<td>"+product.getProductType()+"</td>"
					+ "<td>"+product.getExpiryDate()+"</td>"
					+ "<td>"+product.getDescription()+"</td>"
					+ "<td>"+product.getQuantity()+"</td>"
					+ "<td>"+product.getPrice()+"</td>"
							+ "<td><a href='deleteServlet?productId="+product.getProductId()
							+"'>Delete</a> &nbsp; &nbsp;"
							+ "<a href='#'>Update</a></td>"
/*
					+ "<td>"
					+ "<input type='hidden' name='productId' value='"+product.getProductId()+"'/>"
					+ "<input type='submit' value='Delete'/> &nbsp; &nbsp;"
					+ "<a href='#'>Update</a></td>"*/
					+ "</tr>");
				
		}
		out.println( "</table></form></body></html>");
	
	}

}
