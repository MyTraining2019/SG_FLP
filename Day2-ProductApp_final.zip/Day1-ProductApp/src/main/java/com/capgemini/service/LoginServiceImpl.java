package com.capgemini.service;

import java.util.List;

import com.capgemini.dao.LoginDao;
import com.capgemini.dao.LoginDaoImpl;
import com.capgemini.model.Login;
import com.capgemini.model.Product;

public class LoginServiceImpl implements LoginService{
	
	private LoginDao loginDao=new LoginDaoImpl();

	@Override
	public boolean isValidUser(Login login) {
			/*if(login.getUserName().equals("tom")&&
					login.getUserPwd().equals("tom123"))
			return true;*/
		
		return loginDao.isValidLogin(login);
	}

	@Override
	public void createProduct(Product product) {
		loginDao.createProduct(product);
	}

	@Override
	public List<Product> getAllProducts() {
		
		return loginDao.getAllProducts();
	}

	@Override
	public void deleteProduct(int productId) {
		loginDao.deleteProduct(productId);
	}

}
