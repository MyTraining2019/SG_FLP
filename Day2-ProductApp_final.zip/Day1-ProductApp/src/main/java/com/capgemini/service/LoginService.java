package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Login;
import com.capgemini.model.Product;

public interface LoginService {
	
	public boolean isValidUser(Login login);
	public void createProduct(Product product);
	public List<Product> getAllProducts();
	public void deleteProduct(int productId);
}
