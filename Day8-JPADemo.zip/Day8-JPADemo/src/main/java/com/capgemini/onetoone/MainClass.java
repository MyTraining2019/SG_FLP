package com.capgemini.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf
		=Persistence.createEntityManagerFactory("jpademo");
	EntityManager entityManager= emf.createEntityManager();
	
	EntityTransaction entityTransaction
		= entityManager.getTransaction();
	
	Address address=new Address(11,"12/A", "South Bridge Rd", "Singapore");
	Customer customer=new Customer("Tom", "Jerry", address);
	
	Address address1=new Address(12,"13/A", "North Bridge Rd", "Singapore");
	Customer customer1=new Customer("Tom", "Jerry", address1);
	
	entityTransaction.begin();
	entityManager.persist(customer);
	entityManager.persist(address);
	entityManager.persist(customer1);
	entityManager.persist(address1);
	entityTransaction.commit();
	}

}
