package com.capgemini.onetoone;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class Address {
	@Id
	//@GeneratedValue
	private int addressId;
	private String doorNo;
	private String address;
	private String city;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="customer_custId")
	private Customer customer;
	
	public Address() {}
	public Address( String doorNo, String address, String city) {
		super();
		
		this.doorNo = doorNo;
		this.address = address;
		this.city = city;
	}
	
	public Address(int addressId, String doorNo, String address, String city) {
		super();
		this.addressId = addressId;
		this.doorNo = doorNo;
		this.address = address;
		this.city = city;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", doorNo=" + doorNo + ", address=" + address + ", city=" + city
				+ "]";
	}
	
	
	
}
