package com.capgemini.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf
		=Persistence.createEntityManagerFactory("jpademo");
	EntityManager entityManager= emf.createEntityManager();
	
	EntityTransaction entityTransaction
		= entityManager.getTransaction();
	
	
	entityTransaction.begin();
	
	/*Company company=new Company(1001,"Capgemini Pvt Ltd");
	Company company1=new Company(1002,"Scope International Bank");
	
	Employee employee=new Employee("tom", "jerry", company1);
	Employee employee1=new Employee("Jack", "hendry", company1);
	Employee employee2=new Employee("emi", "thomson", company);
	
	entityManager.persist(company);
	entityManager.persist(company1);
	entityManager.persist(employee2);
	entityManager.persist(employee1);
	entityManager.persist(employee);*/
	
	Company company2=entityManager.find(Company.class, 1001);
	System.out.println(company2);
	entityTransaction.commit();
	
	}

}
