package com.capgemini.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf
		=Persistence.createEntityManagerFactory("jpademo");
	EntityManager entityManager= emf.createEntityManager();
	
	EntityTransaction entityTransaction
		= entityManager.getTransaction();
	
	
	entityTransaction.begin();
	
	Event java=new Event();
	java.setEventId(101);
	java.setEventName("Java_101");
	
	Event oracle=new Event();
	oracle.setEventId(102);
	oracle.setEventName("oracle_123");
	
	Event angular=new Event();
	angular.setEventId(103);
	angular.setEventName("Angular_190");
	
	
	Delegate delegate=new Delegate(1,"Tom");
	delegate.getEvents().add(angular);
	delegate.getEvents().add(java);
	
	Delegate delegate1=new Delegate(2,"Jack");
	delegate1.getEvents().add(oracle);
	delegate1.getEvents().add(java);
	delegate1.getEvents().add(angular);
	
	entityManager.persist(java);
	entityManager.persist(oracle);
	entityManager.persist(angular);
	entityManager.persist(delegate1);
	entityManager.persist(delegate);
	
	entityTransaction.commit();
	
	}

}
