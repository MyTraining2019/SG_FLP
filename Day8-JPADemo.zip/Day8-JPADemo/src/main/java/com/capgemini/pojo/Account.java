package com.capgemini.pojo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {
	
	@Id
	private AccountId accountId;
	private String accountName;
	private Date openDate;
	private double balance;
	
	public Account() {}
	
	public Account(AccountId accountId, String accountName, Date openDate, double balance) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.openDate = openDate;
		this.balance = balance;
	}
	public AccountId getAccountId() {
		return accountId;
	}
	public void setAccountId(AccountId accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountName=" + accountName + ", openDate=" + openDate
				+ ", balance=" + balance + "]";
	}
	
	
	
	
	

}
