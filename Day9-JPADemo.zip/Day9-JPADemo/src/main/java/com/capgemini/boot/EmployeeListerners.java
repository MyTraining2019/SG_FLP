package com.capgemini.boot;

import javax.persistence.PostPersist;
import javax.persistence.PrePersist;

public class EmployeeListerners {

	@PrePersist
	public void pre_perist_method(Employee_Info emp) {
		System.out.println("Object persist..." + emp.getEmpId());
	}
	
	@PostPersist
	public void ppost_perist_method(Employee_Info emp) {
		System.out.println("Object persisted..." + emp.getEmpId());
	}
}
