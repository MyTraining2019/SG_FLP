package com.capgemini.boot;

import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OrderColumn;
import javax.persistence.PostPersist;
import javax.persistence.PrePersist;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="emp_details")
@SecondaryTable(name="employee_information")
@EntityListeners(EmployeeListerners.class)
@Cacheable(true)
public class Employee_Info {
	
	@Id
	@GeneratedValue
	private int empId;
	
	@Column(name="employee_firstName")
	private String firstName;
	private String lastName;
	private double salary;
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateOfBirth;
	
	@Column(table="employee_information")
	private Date dateOfJoin;
	
	@OrderColumn(name="phone_seq")
	@ElementCollection
	private List<String> phones;
	
	@Column(nullable=false,table="employee_information")
	private String email;
	
	@Basic
	@Column(table="employee_information")
	private boolean isPermanent;
	
	@Transient
	private String empPassword;
	
	public Employee_Info() {}
	
	
	
	public Employee_Info(String firstName, String lastName, double salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}



	public List<String> getPhones() {
		return phones;
	}



	public void setPhones(List<String> phones) {
		this.phones = phones;
	}



	public Employee_Info(String firstName, String lastName, double salary, Date dateOfBirth, Date dateOfJoin, String email,
			boolean isPermanent, String empPassword) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoin = dateOfJoin;
		this.email = email;
		this.isPermanent = isPermanent;
		this.empPassword = empPassword;
	}



	public Employee_Info(int empId, String firstName, String lastName, double salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfJoin() {
		return dateOfJoin;
	}

	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isPermanent() {
		return isPermanent;
	}

	public void setPermanent(boolean isPermanent) {
		this.isPermanent = isPermanent;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public Employee_Info(int empId, String firstName, String lastName, double salary, Date dateOfBirth, Date dateOfJoin,
			String email, boolean isPermanent, String empPassword) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoin = dateOfJoin;
		this.email = email;
		this.isPermanent = isPermanent;
		this.empPassword = empPassword;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", dateOfBirth=" + dateOfBirth + ", dateOfJoin=" + dateOfJoin + ", email=" + email + ", isPermanent="
				+ isPermanent + ", empPassword=" + empPassword + "]";
	}

	

}
