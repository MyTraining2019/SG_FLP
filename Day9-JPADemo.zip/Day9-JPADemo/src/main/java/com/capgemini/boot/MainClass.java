package com.capgemini.boot;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;



public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf
			=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		
		EntityTransaction entityTransaction
			= entityManager.getTransaction();
		
		/*Employee_Info employee=new Employee_Info("Tom", "Jerry", 2300,new Date(),new Date(2008-1900, 4, 11),
				"tom@gmail.com",true,"tom123");*/
		/*Employee_Info employee1=new Employee_Info("Jack", "Samsung", 1200,new Date(1991-1900, 4, 11),new Date(2008-1900, 4, 11),
				"Jack@gmail.com",true,"Jack123");
		
		Employee_Info employee2=new Employee_Info("Emi", "Thomson", 4500,new Date(1989-1900, 4, 11),new Date(2008-1900, 4, 11),
				"emi@gmail.com",false,"emi123");*/
		
		/*List<String> empphones=new ArrayList<>();
		empphones.add("4353454");
		empphones.add("6776657");
		empphones.add("1234545");*/
		
	//	employee.setPhones(empphones);
		
		entityTransaction.begin();
		//entityManager.persist(employee);
		/*entityManager.persist(employee1);
		entityManager.persist(employee2);*/
		entityTransaction.commit();
		
		entityTransaction.begin();
		Employee_Info employee=entityManager.find(Employee_Info.class, 1);
		
		System.out.println(employee.getPhones());
		entityTransaction.commit();
		
		//employee.setFirstName("Kamal");
		
		//entityManager.remove(employee);
		/*List<Employee> employees
			=entityManager.createQuery("from Employee").getResultList();
		*/
		/*List<String> employees
		=entityManager.createQuery("select firstName from Employee").getResultList();
	
		System.out.println(employees);
		*/
		
		/*List<Employee> employees
		=entityManager.createQuery("select new Employee(firstName,lastName,salary) from Employee").getResultList();
		for(Employee employee:employees)
			System.out.println(employee);*/
		
		
		/*List<Object> employees
		=entityManager.createQuery("select new Map(empId,firstName) from Employee").getResultList();
		for(Object employee:employees)
			System.out.println(employee);
		entityTransaction.commit();*/
		
		/*for(Employee employee:employees)
			System.out.println(employee);*/
	}

}
