package com.capgemini.inherit;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;

@Entity
public class Task extends Module{

	@ElementCollection
	private List<String> taskName;

	public Task() {}
	
	

	public Task(List<String> taskName) {
		super();
		this.taskName = taskName;
	}



	public List<String> getTaskName() {
		return taskName;
	}

	public void setTaskName(List<String> taskName) {
		this.taskName = taskName;
	}

	@Override
	public String toString() {
		return "Task [taskName=" + taskName + "]";
	}
	

	
}
