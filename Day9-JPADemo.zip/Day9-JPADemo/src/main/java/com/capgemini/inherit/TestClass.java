package com.capgemini.inherit;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		
		EntityTransaction entityTransaction= entityManager.getTransaction();
		
		entityTransaction.begin();
			Project project=new Project();
			project.setProjectId(1);
			project.setProjectName("FundTransfer Within Bank");
			
			Module module=new Module();
			module.setProjectId(12);
			module.setProjectName("FundTransfer other Banks");
			module.setModuleName("NEFT FundTransfer");
			
			
			Task task=new Task();
			task.setProjectId(3);
			task.setProjectName("Payment Gateway Interaction");
			task.setModuleName("NEFT Transfer");
			//task.setTaskName("FundTransfer with specific limit");
			
			List<String> task_name=new ArrayList<String>();
			task_name.add("T1");
			task_name.add("T2");
			task.setTaskName(task_name);
			
			Task task1=new Task();
			task1.setProjectId(13);
			task1.setProjectName("Payment Gateway ");
			task1.setModuleName("NEFT Transfer B");
			//task1.setTaskName("Task B");
			
			List<String> task1_name=new ArrayList<String>();
			task1_name.add("A1");
			task1_name.add("B2");
			task1.setTaskName(task1_name);
			
			
			entityManager.persist(project);
			entityManager.persist(module);
			entityManager.persist(task);
			entityManager.persist(task1);
		
		entityTransaction.commit();
		
	}

}
