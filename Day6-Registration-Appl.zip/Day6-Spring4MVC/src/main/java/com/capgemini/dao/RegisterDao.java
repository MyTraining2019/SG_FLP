package com.capgemini.dao;

import java.util.List;

import com.capgemini.pojo.Register;

public interface RegisterDao {
	
	public void registerAccount(Register register);
	public List<Register> getAllRegistration();
	public void deleteRegistration(Integer registerId);
	public Register findRegistrationById(Integer registerId);

}
