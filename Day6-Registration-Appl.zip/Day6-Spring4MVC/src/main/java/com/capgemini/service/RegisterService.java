package com.capgemini.service;

import java.util.List;

import com.capgemini.pojo.Register;

public interface RegisterService {
	public void registerAccount(Register register);
	public List<Register> getAllRegistration() ;
	public void deleteRegistration(Integer registerId);
	public Register findRegistrationById(Integer registerId);
}
