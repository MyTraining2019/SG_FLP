package com.capgemini.pojo;

import java.util.Date;

import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

public class Register {

	private int registerid;
	@NotEmpty(message="* Please enter FirstName")
	private String firstName;
	@NotEmpty(message="* Please enter LastName")
	private String lastName;
	@Past(message="* Date of Birth must be past date.")
	private Date dob;
	private String address;
	private String occupation;
	
	@NotEmpty(message="* Please select gender")
	private String gendar;
	
	@NotEmpty(message="* Please enter email")
	@Email(message="* Sorry invalid Email!")
	private String email;
	
	@NotEmpty(message="* Please enter mobile")
	@Length(min=8,max=8,message="* Mobile number must be 8 digit" )
	private String mobile;
	
	public Register() {}
	
	

	public Register(int registerid, String firstName, String lastName, Date dob, String address, String occupation,
			String gendar, String email, String mobile) {
		super();
		this.registerid = registerid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.address = address;
		this.occupation = occupation;
		this.gendar = gendar;
		this.email = email;
		this.mobile = mobile;
	}



	public int getRegisterid() {
		return registerid;
	}

	public void setRegisterid(int registerid) {
		this.registerid = registerid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getGendar() {
		return gendar;
	}

	public void setGendar(String gendar) {
		this.gendar = gendar;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Register [registerid=" + registerid + ", firstName=" + firstName + ", lastName=" + lastName + ", dob="
				+ dob + ", address=" + address + ", occupation=" + occupation + ", gendar=" + gendar + ", email="
				+ email + ", mobile=" + mobile + "]";
	}
	
	
	
	
}
