package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.RegisterDao;
import com.capgemini.pojo.Register;

@Service("registerService")
public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	private RegisterDao registerDao;

	public void registerAccount(Register register) {
		registerDao.registerAccount(register);
	}

	public List<Register> getAllRegistration() {
		
		return registerDao.getAllRegistration();
	}

	public void deleteRegistration(Integer registerId) {
		registerDao.deleteRegistration(registerId);
	}

	public Register findRegistrationById(Integer registerId) {
		
		return registerDao.findRegistrationById(registerId);
	}

	public void updateRegistration(Register register) {
		registerDao.updateRegistration(register);
	}

}
