package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.pojo.Register;
import com.capgemini.service.RegisterService;

@Controller
public class RegisterController {
	
	@Autowired
	private RegisterService registerService;
	private boolean flag=false;
	private Register updateRegister;
	
	
	@RequestMapping("/register")
	public String showRegisterForm(ModelMap map) {
		if(flag==false) {
		map.put("registerObj",new Register());
		}
		else
		{
			map.put("editregister", updateRegister);
		}
		map.put("flag", flag);
		map.put("occupations", getOccupation());
		map.put("registrations", registerService.getAllRegistration());
		return "register";
	}
	
	@RequestMapping(value="/saveRegistration",method=RequestMethod.POST)
	public String saveRegistration(@Valid @ModelAttribute("registerObj")Register register,
				BindingResult result,ModelMap map) {
		map.put("occupations", getOccupation());
		if(result.hasErrors()) {
			return "register";
		}else {
			registerService.registerAccount(register);
			//System.out.println(register);
			return "redirect:register";
		}
	}
	
	
	public List<String> getOccupation(){
		List<String> occupation=new ArrayList<String>();
		occupation.add("public");
		occupation.add("private");
		occupation.add("self-employment");
		occupation.add("government");
		occupation.add("others");
		return occupation;
	}
	
	
	@RequestMapping("/delete/{registrationId}")
	public String deleteRegistration(
			@PathVariable("registrationId") Integer registerId) {
		registerService.deleteRegistration(registerId);
		
		return "redirect:/register";
	}
	
	
	@RequestMapping("/edit/{registrationId}")
	public String editRegistration(
			@PathVariable("registrationId") Integer registerId,
			ModelMap map)  {
		flag=true;
		
		updateRegister=registerService.findRegistrationById(registerId);
		System.out.println(updateRegister);
	
		return "redirect:/register";
	}
	
	@RequestMapping(value="/updateRegistration",method=RequestMethod.POST)
	public String updateRegistratoin(@Valid @ModelAttribute("editregister") Register register,
			BindingResult result) {
		if(result.hasErrors()){
			return "register";
		}else {
		registerService.updateRegistration(register);
		flag=false;
		return "redirect:register";
		}
	}
	
	
	
	
	

}
