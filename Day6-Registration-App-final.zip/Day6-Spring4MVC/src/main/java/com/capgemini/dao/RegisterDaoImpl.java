package com.capgemini.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.capgemini.pojo.Register;

@Repository("registerDao")
public class RegisterDaoImpl implements RegisterDao {

	@Autowired
	private JdbcTemplate jdbcTemp;
	
	public void registerAccount(Register register) {
		
		String sql="insert into register(firstName,lastName,dob,address,occupation,gendar,email,mobile) " + 
				"values(?,?,?,?,?,?,?,?)";
		jdbcTemp.update(sql,register.getFirstName(),register.getLastName(),register.getDob(),register.getAddress(),
					register.getOccupation(),register.getGendar(),register.getEmail(),register.getMobile());
				
	}

	public List<Register> getAllRegistration() {
		String sql="select * from register";
		List<Register> registers=jdbcTemp.query(sql, new BeanPropertyRowMapper(Register.class));
		return registers;
	}

	public void deleteRegistration(Integer registerId) {
		String  sql="delete from register where registerid=?";
		jdbcTemp.update(sql,registerId);
	}

	public Register findRegistrationById(Integer registerId) {
		String  sql="select * from register where registerid=?";
		Register register=jdbcTemp.queryForObject(sql, 
				new BeanPropertyRowMapper<Register>(Register.class), registerId);
		
		return register;
	}

	public void updateRegistration(Register register) {
		String sql="update register set firstName=?,lastName=?,dob=?,address=?,occupation=?,gendar=?,email=?,mobile=? where registerid=?"; 
		jdbcTemp.update(sql,register.getFirstName(),register.getLastName(),register.getDob(),register.getAddress(),
				register.getOccupation(),register.getGendar(),register.getEmail(),register.getMobile(),register.getRegisterid());
		
	}
	
	
	
	

}
